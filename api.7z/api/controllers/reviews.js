const ObjectID = require('mongodb').ObjectID;
const sanitize = require('mongo-sanitize');
const { pick, isEmpty } = require('lodash');

var createReviewModel = [ 'event_id', 'description', 'rating'];


const getReviews = (req, res, dbClient) => {
    const eventId = sanitize(req.params.eventId);

    if (ObjectID.isValid(ticketId)) {
        dbClient.collection('reviews')
            .find({ event_id: ObjectID(eventId) })
            .toArray()
            .then(reviews =>  res.json(reviews));
    } else {
        res.status(400).send({status: 'MISSING_FIELDS'});
    }
}


const createReview = (req, res, dbClient) => {
    // const newReviewData = sanitize(pick(req.body, createReviewModel));
    const eventId = sanitize(req.params.eventId);
    const newReviewData = {
        ...ObjectID.isValid(eventId) ? { 'event_id': ObjectID(eventId) } : {},
        'description': 'description',
        'rating': 5
    };

    if (ObjectID.isValid(eventId) && !isEmpty(newReviewData)) {
        dbClient.collection('reviews')
            .insertOne(newReviewData)
            .then(entry => res.status(200).send({ status: 'OK'}));
    } else {
        res.status(400).send({status: 'MISSING_FIELDS'});
    }
}


exports.getReviews = getReviews;
exports.createReview = createReview;
