const ObjectID = require('mongodb').ObjectID;
const sanitize = require('mongo-sanitize');
const { pick } = require('lodash');
const bookingStatuses = require('../utils/bookingStatuses.json');


const getBookings = (req, res, dbClient) => {
    const userId = sanitize(req.userId);

    if (ObjectID.isValid(userId)) {
        dbClient.collection('bookings')
            .find({ user_id: ObjectID(userId) })
            .toArray()
            .then(reviews =>  res.json(reviews));
    } else {
        res.status(400).send({status: 'MISSING_FIELDS'});
    }
}


const createBooking = (req, res, dbClient) => {
    const userId = sanitize(req.userId);
    const ticketId = sanitize(req.params.ticketId);

    const newBookingData = {
        ...ObjectID.isValid(userId) ? { 'user_id': ObjectID(userId) } : {},
        ...ObjectID.isValid(ticketId) ? { 'ticket_id': ObjectID(ticketId) } : {},
        status: bookingStatuses.pending
    };

    if (ObjectID.isValid(userId) && ObjectID.isValid(ticketId)) {
        dbClient.collection('bookings')
            .insertOne(newBookingData)
            .then(entry => res.status(200).send({ status: 'OK'}));
    } else {
        res.status(400).send({status: 'MISSING_FIELDS'});
    }
}


const updateBooking = (req, res, dbClient) => {
    const bookingId = sanitize(req.params.bookingId);
    const updateBookingStatus = sanitize(pick(req.body, 'status'));
    const updateBookingStatuses = [bookingStatuses.confirmed, bookingStatuses.canceled];

    if (ObjectID.isValid(bookingId) && updateBookingStatuses.includes(updateBookingStatus)) {
        dbClient.collection('bookings')
            .updateOne({ _id: ObjectID(bookingId) }, { $set: updateBookingStatus })
            .then(entry => res.status(200).send({ status: 'OK'}));
    } else {
        res.status(400).send({status: 'MISSING_FIELDS'});
    }
}


exports.getBookings = getBookings;
exports.createBooking = createBooking;
exports.updateBooking = updateBooking;